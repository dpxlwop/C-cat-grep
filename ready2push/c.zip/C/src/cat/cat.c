#include "cat.h"

#include <getopt.h>
#include <stdio.h>
#include <string.h>

#define MAX_LINE_LENGTH 1024

struct option long_options[] = {{"number-nonblank", no_argument, 0, 'b'},
                                {"number", no_argument, 0, 'n'},
                                {"squeeze-blank", no_argument, 0, 's'},
                                {0, 0, 0, 0}};

int main(int argc, char **argv) {
  flags flag_container = {0};
  if (argc < 2) {
    fprintf(stderr, "Usage: %s <options> <file1> [file2] ...\n", argv[0]);
    return 1;
  }
  int rez = 0;
  int option_index;
  while ((rez = getopt_long(argc, argv, "benstvET", long_options,
                            &option_index)) != -1) {
    switch (rez) {
      case 'b':
        flag_container.b = 1;
        break;
      case 'e':
        flag_container.v = 1;
        /* FALL THROUGH */
      case 'E':
        flag_container.e = 1;
        break;
      case 'n':
        flag_container.n = 1;
        break;
      case 's':
        flag_container.s = 1;
        break;
      case 't':
        flag_container.v = 1;
        /* FALL THROUGH */
      case 'T':
        flag_container.t = 1;
        break;
      case 'v':
        flag_container.v = 1;
        break;
      default:
        fprintf(stderr, "Unknown option '%c'\n", optopt);
        return 1;
    }
  }
  if (flag_container.b == 1 && flag_container.n == 1) flag_container.n = 0;
  for (int i = optind; i < argc; i++) file_proccess(argv[i], flag_container);
  return 0;
}

int file_proccess(const char *filename, flags flag_container) {
  FILE *file = fopen(filename, "r");
  if (!file) {
    fprintf(stderr, "File %s does not exists.\n", filename);
    return 1;
  }
  char string[MAX_LINE_LENGTH];
  int line_number = 1;
  int empty_streak = 0;

  while (fgets(string, MAX_LINE_LENGTH, file) != NULL) {
    int is_empty_line = (string[0] == '\n');
    if (flag_container.s && is_empty_line) {
      if (empty_streak) continue;
      empty_streak = 1;
    } else {
      empty_streak = 0;
    }
    int need_number = (flag_container.b && !is_empty_line) ||
                      (flag_container.n && !flag_container.b);
    if (need_number) {
      printf("%6d\t", line_number++);
    }
    replace_symbols(string, flag_container.v, flag_container.t);
    if (flag_container.e && flag_container.b && is_empty_line)
      printf("      	$");
    else if (flag_container.e)
      printf("$");
    printf("\n");
  }
  fclose(file);
  return 0;
}

void replace_symbols(char *string, int flag_v, int flag_t) {
  for (unsigned char *p = (unsigned char *)string; *p != '\n'; p++) {
    if (*p == '\t' && flag_t)
      printf("^I");
    else if (flag_v)
      print_visible_char(*p);
    else
      putchar(*p);
  }
}

void print_visible_char(unsigned char c) {
  if (c >= 32 && c < 127)
    putchar(c);
  else if (c == 9 || c == 10)
    putchar(c);
  else if (c < 32)
    printf("^%c", c + 64);
  else if (c == 127)
    printf("^?");
  else {
    printf("M-");
    if (c >= 160)
      putchar(c - 128);
    else
      print_visible_char(c - 128);
  }
}